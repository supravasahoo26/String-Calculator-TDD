// stringCalculator.js

function add(numbers) {
    if (numbers === "") return 0; // Handle empty string
    
    const delimiters = [',', '\n']; // Default delimiters
    
    // Check for custom delimiter (e.g., "//;\n1;2")
    if (numbers.startsWith("//")) {
        const delimiterLineEnd = numbers.indexOf("\n");
        const delimiter = numbers.substring(2, delimiterLineEnd);
        numbers = numbers.substring(delimiterLineEnd + 1);
        delimiters.push(delimiter);  // Add custom delimiter
    }

    // Split by any delimiter
    const numberArray = numbers.split(new RegExp(`[${delimiters.join('')}]`));
    
    let sum = 0;
    let negatives = [];
    
    numberArray.forEach(num => {
        const n = parseInt(num);
        if (n < 0) {
            negatives.push(n);
        } else {
            sum += n;
        }
    });
    
    // Handle negative numbers
    if (negatives.length > 0) {
        throw new Error("Negative numbers not allowed: " + negatives.join(", "));
    }
    
    return sum;
}

module.exports = { add };
